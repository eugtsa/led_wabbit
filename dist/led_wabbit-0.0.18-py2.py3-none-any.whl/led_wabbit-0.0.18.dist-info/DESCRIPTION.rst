led_wabbit - wrapper with sklearn interface for vowpal wabbit
=======================

This package provides wrapper with sklearn interfaces for machine learning tool vowpal wabbit.
This wrapper based on vowpal_porpoise (https://github.com/josephreisinger/vowpal_porpoise) developed by Austin Waters, Joseph Reisinger and Daniel Duckworth.
----

Install and update package with command on python2:
pip install -i https://testpypi.python.org/pypi led_wabbit --user --upgrade

Install and update package with command on python3:
pip3 install -i https://testpypi.python.org/pypi led_wabbit --user --upgrade
----

Currently implements linear regression(LinearRegression), logistic regression(LogisticRegressionBinary), multiclass one-versus-all regression(MulticlassOAA). 
These classes support sklearn interface with fit(), predict(), predict_proba() methods.  
----


